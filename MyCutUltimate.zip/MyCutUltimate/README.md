# MyCut Ultimate

Бесплатный видеоредактор для Android: без подписок, рекламы, регистрации и водяных знаков.

**Статус: этап 1 (v0.1.0).** Это рабочая основа, а не готовый аналог CapCut Pro. Список реализованного и план — ниже.

## Что уже работает

- Проекты: создание, автосохранение (Room), открытие, дублирование, удаление, восстановление после закрытия приложения.
- Импорт видео через Storage Access Framework (несколько файлов сразу).
- Предпросмотр на Media3 / ExoPlayer, перемотка по слайдеру и по тапу на таймлайне.
- Таймлайн: клипы пропорциональной ширины, выбор клипа, масштаб, курсор воспроизведения.
- Монтаж: обрезка (двойной ползунок), разделение по курсору, удаление, копирование, перестановка клипов, склейка в порядке таймлайна, Undo / Redo.
- Фильтры (OpenGL ES через Media3 Effects, одинаково в предпросмотре и экспорте): Ч/Б, насыщенный, яркий, контраст.
- Экспорт в MP4 (H.264 + AAC), 720p / 1080p / как в исходнике, прогресс, отмена, сохранение в `Movies/MyCut`.

## Чего пока нет (план)

Скорость и reverse, поворот/кадрирование, остальные фильтры и переходы, текст и субтитры, аудиодорожки и запись голоса, ключевые кадры, AI-функции (субтитры, удаление тишины и т. д.), HEVC/4K/FPS/битрейт, экспорт в foreground-сервисе, несколько дорожек.

## Технологии

Kotlin 2.0, Jetpack Compose (Material 3), Media3 1.4.1 (ExoPlayer, Effect, Transformer), Room 2.6.1 + KSP, Coroutines. minSdk 29, targetSdk 35.

FFmpegKit не используется: проект был снят с поддержки. Обработка видео идёт через Media3 Transformer, он поддерживается Google и использует аппаратные кодеки.

## Сборка через GitHub Actions

1. Создайте репозиторий на GitHub и загрузите содержимое этой папки:
   ```bash
   git init
   git add .
   git commit -m "MyCut Ultimate"
   git branch -M main
   git remote add origin https://github.com/<ваш-логин>/<репозиторий>.git
   git push -u origin main
   ```
2. Откройте вкладку **Actions** — workflow **Build APK** запустится сам (или нажмите **Run workflow**).
3. После успешной сборки откройте запуск и скачайте артефакт **MyCutUltimate-debug-apk** со страницы запуска.
4. Для релиза создайте тег `v0.1.0`: APK прикрепится к GitHub Release.

Workflow сам устанавливает JDK 17, Android SDK и Gradle 8.9, поэтому `gradle-wrapper.jar` в репозитории не нужен.

## Локальная сборка

Нужны JDK 17 и Android SDK 35. Один раз сгенерируйте wrapper, затем собирайте:

```bash
gradle wrapper --gradle-version 8.9
./gradlew assembleDebug
```

APK: `app/build/outputs/apk/debug/app-debug.apk`.

## Структура

```
app/src/main/java/com/mycut/ultimate/
  MainActivity.kt, MyCutApp.kt
  data/    Models.kt, ProjectDb.kt, ProjectRepository.kt
  media/   MediaEngine.kt (фильтры, MediaItem), VideoExporter.kt
  ui/      theme/, home/, editor/
.github/workflows/build.yml
```

## Лицензия

MIT, см. `LICENSE`.
