package com.mycut.ultimate.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val Accent = Color(0xFF00E5C3)
val Background = Color(0xFF0E0F13)
val Surface = Color(0xFF181A20)
val SurfaceHigh = Color(0xFF23262E)

private val DarkColors = darkColorScheme(
    primary = Accent,
    onPrimary = Color(0xFF00201B),
    secondary = Color(0xFF7C9CFF),
    background = Background,
    onBackground = Color(0xFFECEDEF),
    surface = Surface,
    onSurface = Color(0xFFECEDEF),
    surfaceVariant = SurfaceHigh,
    onSurfaceVariant = Color(0xFFB4B8C2),
    error = Color(0xFFFF6B6B),
)

@Composable
fun MyCutTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = DarkColors, content = content)
}
