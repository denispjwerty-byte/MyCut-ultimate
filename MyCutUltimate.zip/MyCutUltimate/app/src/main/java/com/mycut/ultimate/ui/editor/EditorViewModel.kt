package com.mycut.ultimate.ui.editor

import android.app.Application
import android.content.Intent
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.provider.OpenableColumns
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.mycut.ultimate.MyCutApp
import com.mycut.ultimate.data.Adjust
import com.mycut.ultimate.data.AspectPreset
import com.mycut.ultimate.data.Clip
import com.mycut.ultimate.data.FilterPreset
import com.mycut.ultimate.data.Timeline
import com.mycut.ultimate.media.ExportQuality
import com.mycut.ultimate.media.VideoExporter
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

data class EditorUiState(
    val loaded: Boolean = false,
    val name: String = "",
    val timeline: Timeline = Timeline(),
    val selectedClipId: String? = null,
    val canUndo: Boolean = false,
    val canRedo: Boolean = false,
    val importing: Boolean = false,
    val message: String? = null,
) {
    val selectedClip: Clip? get() = timeline.clips.firstOrNull { it.id == selectedClipId }
}

sealed interface ExportState {
    data object Idle : ExportState
    data class Running(val progress: Float) : ExportState
    data class Done(val uri: Uri) : ExportState
    data class Failed(val message: String) : ExportState
}

class EditorViewModel(
    private val app: Application,
    private val projectId: Long,
) : AndroidViewModel(app) {

    private val myApp = app as MyCutApp
    private val repo = myApp.repository

    private val _state = MutableStateFlow(EditorUiState())
    val state: StateFlow<EditorUiState> = _state.asStateFlow()

    private val _export = MutableStateFlow<ExportState>(ExportState.Idle)
    val export: StateFlow<ExportState> = _export.asStateFlow()

    private val undoStack = ArrayDeque<Timeline>()
    private val redoStack = ArrayDeque<Timeline>()
    private var saveJob: Job? = null
    private var progressJob: Job? = null
    private val exporter = VideoExporter(app)
    private var exportFile: File? = null

    init {
        viewModelScope.launch {
            val project = repo.load(projectId)
            _state.update {
                it.copy(
                    loaded = true,
                    name = project?.name ?: "Проект",
                    timeline = project?.let { p -> Timeline.fromJson(p.timelineJson) } ?: Timeline(),
                    message = if (project == null) "Проект не найден" else null,
                )
            }
        }
    }

    // ---------- редактирование ----------

    private fun commit(newTimeline: Timeline, selected: String? = _state.value.selectedClipId) {
        val current = _state.value.timeline
        if (newTimeline == current) return
        undoStack.addLast(current)
        if (undoStack.size > 100) undoStack.removeFirst()
        redoStack.clear()
        _state.update {
            it.copy(
                timeline = newTimeline,
                selectedClipId = selected?.takeIf { id -> newTimeline.clips.any { c -> c.id == id } },
                canUndo = true,
                canRedo = false,
            )
        }
        scheduleSave()
    }

    fun undo() {
        val prev = undoStack.removeLastOrNull() ?: return
        redoStack.addLast(_state.value.timeline)
        _state.update {
            it.copy(
                timeline = prev,
                selectedClipId = it.selectedClipId?.takeIf { id -> prev.clips.any { c -> c.id == id } },
                canUndo = undoStack.isNotEmpty(),
                canRedo = true,
            )
        }
        scheduleSave()
    }

    fun redo() {
        val next = redoStack.removeLastOrNull() ?: return
        undoStack.addLast(_state.value.timeline)
        _state.update {
            it.copy(
                timeline = next,
                selectedClipId = it.selectedClipId?.takeIf { id -> next.clips.any { c -> c.id == id } },
                canUndo = true,
                canRedo = redoStack.isNotEmpty(),
            )
        }
        scheduleSave()
    }

    fun selectClip(id: String?) = _state.update { it.copy(selectedClipId = id) }

    fun addMedia(uris: List<Uri>) {
        if (uris.isEmpty()) return
        viewModelScope.launch {
            _state.update { it.copy(importing = true) }
            val results = withContext(Dispatchers.IO) { uris.map { readClip(it) } }
            val clips = results.mapNotNull { it.getOrNull() }
            val failed = results.size - clips.size
            if (clips.isNotEmpty()) {
                val tl = _state.value.timeline
                commit(tl.copy(clips = tl.clips + clips), clips.last().id)
            }
            _state.update {
                it.copy(
                    importing = false,
                    message = if (failed > 0) "Не удалось импортировать файлов: $failed (нужен видеофайл)" else it.message,
                )
            }
        }
    }

    private fun readClip(uri: Uri): Result<Clip> = runCatching {
        runCatching {
            app.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        val retriever = MediaMetadataRetriever()
        try {
            retriever.setDataSource(app, uri)
            val hasVideo = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_HAS_VIDEO) == "yes"
            val duration = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
            require(hasVideo && duration > 0) { "Не видеофайл" }
            Clip(uri = uri.toString(), name = displayName(uri), sourceDurationMs = duration, startMs = 0, endMs = duration)
        } finally {
            retriever.release()
        }
    }

    private fun displayName(uri: Uri): String =
        runCatching {
            app.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                if (c.moveToFirst()) c.getString(0) else null
            }
        }.getOrNull() ?: "Клип"

    /** Разрезает клип под позицией [globalMs] на два. */
    fun splitAt(globalMs: Long) {
        val tl = _state.value.timeline
        val (index, rel) = tl.locate(globalMs) ?: return
        val clip = tl.clips[index]
        if (rel < MIN_CLIP_MS || clip.durationMs - rel < MIN_CLIP_MS) {
            showMessage("Слишком близко к границе клипа")
            return
        }
        val point = clip.startMs + rel
        val first = clip.copy(id = java.util.UUID.randomUUID().toString(), endMs = point)
        val second = clip.copy(id = java.util.UUID.randomUUID().toString(), startMs = point)
        val clips = tl.clips.toMutableList().apply {
            removeAt(index)
            addAll(index, listOf(first, second))
        }
        commit(tl.copy(clips = clips), first.id)
    }

    fun deleteSelected() {
        val tl = _state.value.timeline
        val id = _state.value.selectedClipId ?: return
        commit(tl.copy(clips = tl.clips.filterNot { it.id == id }), null)
    }

    fun duplicateSelected() {
        val tl = _state.value.timeline
        val index = tl.clips.indexOfFirst { it.id == _state.value.selectedClipId }
        if (index < 0) return
        val copy = tl.clips[index].copy(id = java.util.UUID.randomUUID().toString())
        val clips = tl.clips.toMutableList().apply { add(index + 1, copy) }
        commit(tl.copy(clips = clips), copy.id)
    }

    fun moveSelected(delta: Int) {
        val tl = _state.value.timeline
        val index = tl.clips.indexOfFirst { it.id == _state.value.selectedClipId }
        val target = index + delta
        if (index < 0 || target !in tl.clips.indices) return
        val clips = tl.clips.toMutableList().apply { add(target, removeAt(index)) }
        commit(tl.copy(clips = clips))
    }

    fun trimSelected(startMs: Long, endMs: Long) {
        val tl = _state.value.timeline
        val index = tl.clips.indexOfFirst { it.id == _state.value.selectedClipId }
        if (index < 0) return
        val clip = tl.clips[index]
        val s = startMs.coerceIn(0, clip.sourceDurationMs)
        val e = endMs.coerceIn(0, clip.sourceDurationMs)
        if (e - s < MIN_CLIP_MS) return
        val clips = tl.clips.toMutableList().apply { set(index, clip.copy(startMs = s, endMs = e)) }
        commit(tl.copy(clips = clips))
    }

    fun setFilter(filter: FilterPreset) {
        val tl = _state.value.timeline
        commit(tl.copy(filter = filter))
    }

    fun setAdjust(adjust: Adjust) {
        commit(_state.value.timeline.copy(adjust = adjust))
    }

    fun setAspect(aspect: AspectPreset) {
        commit(_state.value.timeline.copy(aspect = aspect))
    }

    fun consumeMessage() = _state.update { it.copy(message = null) }

    private fun showMessage(text: String) = _state.update { it.copy(message = text) }

    // ---------- сохранение ----------

    private fun scheduleSave() {
        saveJob?.cancel()
        saveJob = viewModelScope.launch {
            delay(400)
            repo.save(projectId, _state.value.timeline)
        }
    }

    /** Немедленное сохранение; выполняется в appScope, чтобы не прерываться при закрытии экрана. */
    fun saveNow() {
        if (!_state.value.loaded) return
        saveJob?.cancel()
        val tl = _state.value.timeline
        myApp.appScope.launch { repo.save(projectId, tl) }
    }

    override fun onCleared() {
        saveNow()
        exporter.cancel()
        exportFile?.delete()
        super.onCleared()
    }

    // ---------- экспорт ----------

    fun startExport(quality: ExportQuality) {
        if (_export.value is ExportState.Running) return
        val tl = _state.value.timeline
        if (tl.clips.isEmpty()) return
        val file = File(app.cacheDir, "export_${System.currentTimeMillis()}.mp4")
        exportFile = file
        _export.value = ExportState.Running(0f)

        try {
            exporter.start(tl, quality, file) { error ->
                progressJob?.cancel()
                if (error != null) {
                    file.delete()
                    _export.value = ExportState.Failed(error.message ?: "Ошибка экспорта")
                } else {
                    viewModelScope.launch {
                        val name = _state.value.name.replace(Regex("[^\\p{L}\\p{N}_ -]"), "_")
                        val result = runCatching {
                            withContext(Dispatchers.IO) {
                                VideoExporter.saveToGallery(app, file, "MyCut_${name}_${System.currentTimeMillis()}")
                            }
                        }
                        file.delete()
                        val uri = result.getOrNull()
                        _export.value = if (uri != null) {
                            ExportState.Done(uri)
                        } else {
                            ExportState.Failed(result.exceptionOrNull()?.message ?: "Не удалось сохранить файл")
                        }
                    }
                }
            }
        } catch (e: Exception) {
            file.delete()
            _export.value = ExportState.Failed(e.message ?: "Не удалось запустить экспорт")
            return
        }

        progressJob?.cancel()
        progressJob = viewModelScope.launch {
            while (isActive && exporter.isRunning) {
                exporter.progress()?.let { p ->
                    _export.update { s -> if (s is ExportState.Running) ExportState.Running(p) else s }
                }
                delay(250)
            }
        }
    }

    fun cancelExport() {
        progressJob?.cancel()
        exporter.cancel()
        exportFile?.delete()
        _export.value = ExportState.Idle
    }

    fun dismissExport() {
        if (_export.value !is ExportState.Running) _export.value = ExportState.Idle
    }

    companion object {
        const val MIN_CLIP_MS = 200L
    }
}

class EditorViewModelFactory(
    private val app: Application,
    private val projectId: Long,
) : ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T = EditorViewModel(app, projectId) as T
}
