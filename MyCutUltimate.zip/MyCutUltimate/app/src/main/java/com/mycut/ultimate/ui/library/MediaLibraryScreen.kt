package com.mycut.ultimate.ui.library

import android.content.Intent
import android.net.Uri
import android.provider.Settings
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.mycut.ultimate.media.LibraryItem
import com.mycut.ultimate.media.MediaPermissions
import com.mycut.ultimate.media.Thumbnails
import com.mycut.ultimate.media.formatDuration
import com.mycut.ultimate.ui.theme.Accent
import com.mycut.ultimate.ui.theme.Background
import com.mycut.ultimate.ui.theme.SurfaceHigh
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

private enum class LibraryFilter(val label: String) {
    ALL("Всё"),
    VIDEO("Видео"),
    PHOTO("Фото"),
}

/**
 * Медиатека устройства: сетка фото и видео, фильтры, полноэкранный просмотр.
 * Если передан [onAddVideos], можно выбрать видео и добавить их в проект.
 */
@Composable
fun MediaLibraryScreen(
    onClose: () -> Unit,
    onAddVideos: ((List<Uri>) -> Unit)? = null,
    vm: MediaLibraryViewModel = viewModel(),
) {
    val context = LocalContext.current
    val items by vm.items.collectAsStateWithLifecycle()
    val loading by vm.loading.collectAsStateWithLifecycle()
    val loadedOnce by vm.loadedOnce.collectAsStateWithLifecycle()

    var hasAccess by remember { mutableStateOf(MediaPermissions.hasAccess(context)) }
    var filter by remember { mutableStateOf(LibraryFilter.ALL) }
    var selecting by remember { mutableStateOf(false) }
    var selected by remember { mutableStateOf(emptyList<Uri>()) }
    var viewer by remember { mutableStateOf<LibraryItem?>(null) }

    val permissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { hasAccess = MediaPermissions.hasAccess(context) }

    LaunchedEffect(hasAccess) {
        if (hasAccess) vm.load()
    }

    BackHandler {
        when {
            viewer != null -> viewer = null
            selecting -> {
                selecting = false
                selected = emptyList()
            }
            else -> onClose()
        }
    }

    val visible = remember(items, filter) {
        when (filter) {
            LibraryFilter.ALL -> items
            LibraryFilter.VIDEO -> items.filter { it.isVideo }
            LibraryFilter.PHOTO -> items.filter { !it.isVideo }
        }
    }

    Box(
        Modifier
            .fillMaxSize()
            .background(Background)
            // Не пропускаем касания к экрану под библиотекой.
            .pointerInput(Unit) { detectTapGestures { } }
    ) {
        Column(
            Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding()
        ) {
            Row(
                Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 4.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                TextButton(onClick = onClose) { Text("←", fontSize = 20.sp) }
                Text(
                    "Медиатека",
                    modifier = Modifier.weight(1f),
                    style = MaterialTheme.typography.titleMedium,
                )
                if (onAddVideos != null && hasAccess) {
                    TextButton(onClick = {
                        selecting = !selecting
                        if (!selecting) selected = emptyList()
                    }) { Text(if (selecting) "Отмена" else "Выбрать") }
                }
            }

            if (!hasAccess) {
                PermissionPrompt(
                    onRequest = { permissionLauncher.launch(MediaPermissions.required) },
                    onOpenSettings = {
                        context.startActivity(
                            Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS)
                                .setData(Uri.fromParts("package", context.packageName, null))
                                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        )
                    },
                )
            } else {
                Row(
                    Modifier
                        .horizontalScroll(rememberScrollState())
                        .padding(horizontal = 8.dp),
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                ) {
                    LibraryFilter.entries.forEach { f ->
                        FilterChip(
                            selected = filter == f,
                            onClick = { filter = f },
                            label = { Text(f.label) },
                        )
                    }
                }
                if (selecting) {
                    Text(
                        "Отметьте видео для добавления. Фото можно открыть для просмотра.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp),
                    )
                }

                Box(Modifier.weight(1f)) {
                    when {
                        visible.isNotEmpty() -> LazyVerticalGrid(
                            columns = GridCells.Adaptive(104.dp),
                            contentPadding = PaddingValues(2.dp),
                            horizontalArrangement = Arrangement.spacedBy(2.dp),
                            verticalArrangement = Arrangement.spacedBy(2.dp),
                            modifier = Modifier.fillMaxSize(),
                        ) {
                            items(visible, key = { it.uri.toString() }) { item ->
                                LibraryCell(
                                    item = item,
                                    selectable = selecting && item.isVideo,
                                    isSelected = item.uri in selected,
                                    onClick = {
                                        if (selecting && item.isVideo) {
                                            selected = if (item.uri in selected) {
                                                selected - item.uri
                                            } else {
                                                selected + item.uri
                                            }
                                        } else {
                                            viewer = item
                                        }
                                    },
                                )
                            }
                        }
                        loading || !loadedOnce -> CircularProgressIndicator(Modifier.align(Alignment.Center))
                        else -> Text(
                            "Медиафайлов не найдено",
                            modifier = Modifier.align(Alignment.Center),
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                }

                if (onAddVideos != null && selecting && selected.isNotEmpty()) {
                    Button(
                        onClick = { onAddVideos(selected) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                    ) { Text("Добавить в проект (${selected.size})") }
                }
            }
        }

        viewer?.let { v ->
            val addAction: (() -> Unit)? =
                if (onAddVideos != null && v.isVideo) ({ onAddVideos(listOf(v.uri)) }) else null
            MediaViewer(item = v, onClose = { viewer = null }, onAdd = addAction)
        }
    }
}

@Composable
private fun PermissionPrompt(onRequest: () -> Unit, onOpenSettings: () -> Unit) {
    Column(
        Modifier
            .fillMaxSize()
            .padding(24.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Text(
            "Чтобы показать ваши фото и видео, приложению нужен доступ к медиафайлам. " +
                "Файлы не покидают устройство.",
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        Button(onClick = onRequest, modifier = Modifier.padding(top = 16.dp)) { Text("Разрешить доступ") }
        TextButton(onClick = onOpenSettings) { Text("Открыть настройки приложения") }
    }
}

@Composable
private fun LibraryCell(
    item: LibraryItem,
    selectable: Boolean,
    isSelected: Boolean,
    onClick: () -> Unit,
) {
    val context = LocalContext.current
    val thumb by produceState<ImageBitmap?>(initialValue = null, item.uri) {
        value = withContext(Dispatchers.IO) {
            Thumbnails.load(context, item.uri)?.asImageBitmap()
        }
    }
    Box(
        Modifier
            .aspectRatio(1f)
            .background(SurfaceHigh)
            .then(if (isSelected) Modifier.border(3.dp, Accent) else Modifier)
            .clickable(onClick = onClick)
    ) {
        thumb?.let {
            Image(
                bitmap = it,
                contentDescription = item.name,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize(),
            )
        }
        if (item.isVideo) {
            Text(
                "▶ ${formatDuration(item.durationMs)}",
                color = Color.White,
                fontSize = 11.sp,
                modifier = Modifier
                    .align(Alignment.BottomStart)
                    .background(Color(0x99000000))
                    .padding(horizontal = 4.dp, vertical = 1.dp),
            )
        }
        if (selectable) {
            Box(
                Modifier
                    .align(Alignment.TopEnd)
                    .padding(6.dp)
                    .size(22.dp)
                    .clip(CircleShape)
                    .background(if (isSelected) Accent else Color(0x66000000))
                    .border(1.5.dp, Color.White, CircleShape),
                contentAlignment = Alignment.Center,
            ) {
                if (isSelected) Text("✓", color = Color.Black, fontSize = 13.sp)
            }
        }
    }
}
