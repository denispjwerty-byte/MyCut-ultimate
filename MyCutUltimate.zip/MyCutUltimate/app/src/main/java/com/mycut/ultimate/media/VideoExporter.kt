package com.mycut.ultimate.media

import android.content.ContentValues
import android.content.Context
import android.net.Uri
import android.os.Environment
import android.provider.MediaStore
import androidx.media3.common.Effect
import androidx.media3.common.MimeTypes
import androidx.media3.common.audio.AudioProcessor
import androidx.media3.effect.Presentation
import androidx.media3.transformer.Composition
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.EditedMediaItemSequence
import androidx.media3.transformer.Effects
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.ProgressHolder
import androidx.media3.transformer.Transformer
import com.mycut.ultimate.data.Timeline
import java.io.File

/**
 * Экспорт таймлайна в MP4 (H.264 + AAC) через Media3 Transformer.
 * Методы нужно вызывать с главного потока (Transformer привязан к Looper потока создания).
 */
class VideoExporter(private val context: Context) {

    private var transformer: Transformer? = null

    val isRunning: Boolean get() = transformer != null

    /** [onFinished] получает null при успехе или исключение при ошибке. Не вызывается после cancel(). */
    fun start(timeline: Timeline, quality: ExportQuality, output: File, onFinished: (Throwable?) -> Unit) {
        val effects = buildList<Effect> {
            addAll(FilterEffects.build(timeline.filter, timeline.adjust, timeline.aspect))
            quality.height?.let { add(Presentation.createForHeight(it)) }
        }
        val items = timeline.clips.map { clip ->
            EditedMediaItem.Builder(clip.toMediaItem())
                .setEffects(Effects(emptyList<AudioProcessor>(), effects))
                .build()
        }
        val composition = Composition.Builder(EditedMediaItemSequence(items)).build()

        val t = Transformer.Builder(context)
            .setVideoMimeType(MimeTypes.VIDEO_H264)
            .setAudioMimeType(MimeTypes.AUDIO_AAC)
            .addListener(object : Transformer.Listener {
                override fun onCompleted(composition: Composition, exportResult: ExportResult) {
                    transformer = null
                    onFinished(null)
                }

                override fun onError(
                    composition: Composition,
                    exportResult: ExportResult,
                    exportException: ExportException,
                ) {
                    transformer = null
                    onFinished(exportException)
                }
            })
            .build()
        transformer = t
        t.start(composition, output.absolutePath)
    }

    /** Прогресс 0..1 или null, если пока недоступен. */
    fun progress(): Float? {
        val t = transformer ?: return null
        val holder = ProgressHolder()
        return if (t.getProgress(holder) == Transformer.PROGRESS_STATE_AVAILABLE) {
            holder.progress / 100f
        } else null
    }

    fun cancel() {
        transformer?.cancel()
        transformer = null
    }

    companion object {
        /** Копирует готовый файл в галерею (Movies/MyCut) через MediaStore. */
        fun saveToGallery(context: Context, file: File, displayName: String): Uri? {
            val resolver = context.contentResolver
            val values = ContentValues().apply {
                put(MediaStore.Video.Media.DISPLAY_NAME, "$displayName.mp4")
                put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
                put(MediaStore.Video.Media.RELATIVE_PATH, Environment.DIRECTORY_MOVIES + "/MyCut")
                put(MediaStore.Video.Media.IS_PENDING, 1)
            }
            val uri = resolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values) ?: return null
            try {
                resolver.openOutputStream(uri)?.use { out ->
                    file.inputStream().use { it.copyTo(out) }
                } ?: error("Не удалось открыть выходной поток")
                val done = ContentValues().apply { put(MediaStore.Video.Media.IS_PENDING, 0) }
                resolver.update(uri, done, null, null)
            } catch (e: Exception) {
                resolver.delete(uri, null, null)
                throw e
            }
            return uri
        }
    }
}
