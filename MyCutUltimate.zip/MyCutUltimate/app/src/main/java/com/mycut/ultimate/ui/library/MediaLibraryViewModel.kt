package com.mycut.ultimate.ui.library

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.mycut.ultimate.media.LibraryItem
import com.mycut.ultimate.media.MediaStoreReader
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MediaLibraryViewModel(app: Application) : AndroidViewModel(app) {

    private val _items = MutableStateFlow<List<LibraryItem>>(emptyList())
    val items: StateFlow<List<LibraryItem>> = _items.asStateFlow()

    private val _loading = MutableStateFlow(false)
    val loading: StateFlow<Boolean> = _loading.asStateFlow()

    private val _loadedOnce = MutableStateFlow(false)
    val loadedOnce: StateFlow<Boolean> = _loadedOnce.asStateFlow()

    fun load() {
        viewModelScope.launch {
            _loading.value = true
            val result = withContext(Dispatchers.IO) { MediaStoreReader.read(getApplication<Application>()) }
            _items.value = result
            _loading.value = false
            _loadedOnce.value = true
        }
    }
}
