package com.mycut.ultimate.ui.library

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.rememberTransformableState
import androidx.compose.foundation.gestures.transformable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import com.mycut.ultimate.media.LibraryItem
import com.mycut.ultimate.media.Thumbnails
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/** Полноэкранный просмотр: видео с плеером или фото с зумом (щипок) и сбросом (двойной тап). */
@Composable
fun MediaViewer(item: LibraryItem, onClose: () -> Unit, onAdd: (() -> Unit)?) {
    Box(
        Modifier
            .fillMaxSize()
            .background(Color.Black)
    ) {
        if (item.isVideo) VideoContent(item) else PhotoContent(item)

        Row(
            Modifier
                .fillMaxWidth()
                .statusBarsPadding()
                .background(Color(0x66000000))
                .padding(horizontal = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            TextButton(onClick = onClose) { Text("✕", fontSize = 20.sp, color = Color.White) }
            Text(
                item.name,
                color = Color.White,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.weight(1f),
            )
            if (onAdd != null) {
                Button(
                    onClick = onAdd,
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
                ) { Text("Добавить в проект") }
            }
        }
    }
}

@Composable
private fun VideoContent(item: LibraryItem) {
    val context = LocalContext.current
    val viewerPlayer = remember(item.uri) { ExoPlayer.Builder(context).build() }
    DisposableEffect(viewerPlayer) {
        viewerPlayer.setMediaItem(MediaItem.fromUri(item.uri))
        viewerPlayer.prepare()
        viewerPlayer.playWhenReady = true
        onDispose { viewerPlayer.release() }
    }
    AndroidView(
        factory = { ctx ->
            PlayerView(ctx).apply {
                player = viewerPlayer
                useController = true
            }
        },
        modifier = Modifier.fillMaxSize(),
    )
}

@Composable
private fun PhotoContent(item: LibraryItem) {
    val context = LocalContext.current
    val loaded by produceState<Pair<Boolean, ImageBitmap?>>(initialValue = false to null, item.uri) {
        val bitmap = withContext(Dispatchers.IO) {
            Thumbnails.loadPhoto(context, item.uri)?.asImageBitmap()
        }
        value = true to bitmap
    }
    var scale by remember { mutableFloatStateOf(1f) }
    var offset by remember { mutableStateOf(Offset.Zero) }
    val transformState = rememberTransformableState { zoomChange, panChange, _ ->
        scale = (scale * zoomChange).coerceIn(1f, 6f)
        offset = if (scale > 1f) offset + panChange else Offset.Zero
    }

    Box(
        Modifier
            .fillMaxSize()
            .pointerInput(Unit) {
                detectTapGestures(onDoubleTap = {
                    scale = 1f
                    offset = Offset.Zero
                })
            }
            .transformable(transformState),
        contentAlignment = Alignment.Center,
    ) {
        val bitmap = loaded.second
        when {
            !loaded.first -> CircularProgressIndicator()
            bitmap == null -> Text("Не удалось открыть фото", color = Color.White)
            else -> Image(
                bitmap = bitmap,
                contentDescription = item.name,
                contentScale = ContentScale.Fit,
                modifier = Modifier
                    .fillMaxSize()
                    .graphicsLayer {
                        scaleX = scale
                        scaleY = scale
                        translationX = offset.x
                        translationY = offset.y
                    },
            )
        }
    }
}
