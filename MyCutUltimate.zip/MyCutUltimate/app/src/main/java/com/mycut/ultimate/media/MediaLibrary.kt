package com.mycut.ultimate.media

import android.Manifest
import android.content.ContentUris
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.ImageDecoder
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import android.util.LruCache
import android.util.Size
import androidx.core.content.ContextCompat
import kotlin.math.max

/** Элемент медиатеки устройства: видео или фото. */
data class LibraryItem(
    val uri: Uri,
    val isVideo: Boolean,
    val name: String,
    val durationMs: Long,
    val dateAdded: Long,
)

/** Разрешения на чтение медиафайлов зависят от версии Android. */
object MediaPermissions {
    val required: Array<String>
        get() = when {
            Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE -> arrayOf(
                Manifest.permission.READ_MEDIA_IMAGES,
                Manifest.permission.READ_MEDIA_VIDEO,
                Manifest.permission.READ_MEDIA_VISUAL_USER_SELECTED,
            )
            Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU -> arrayOf(
                Manifest.permission.READ_MEDIA_IMAGES,
                Manifest.permission.READ_MEDIA_VIDEO,
            )
            else -> arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE)
        }

    fun hasAccess(context: Context): Boolean {
        fun granted(permission: String) =
            ContextCompat.checkSelfPermission(context, permission) == PackageManager.PERMISSION_GRANTED
        return when {
            // На Android 14+ пользователь может дать частичный доступ (выбранные фото/видео).
            Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE ->
                (granted(Manifest.permission.READ_MEDIA_IMAGES) && granted(Manifest.permission.READ_MEDIA_VIDEO)) ||
                    granted(Manifest.permission.READ_MEDIA_VISUAL_USER_SELECTED)
            Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU ->
                granted(Manifest.permission.READ_MEDIA_IMAGES) && granted(Manifest.permission.READ_MEDIA_VIDEO)
            else -> granted(Manifest.permission.READ_EXTERNAL_STORAGE)
        }
    }
}

/** Чтение списка фото и видео из MediaStore. Вызывать не на главном потоке. */
object MediaStoreReader {

    fun read(context: Context): List<LibraryItem> {
        val out = ArrayList<LibraryItem>()
        query(context, MediaStore.Images.Media.EXTERNAL_CONTENT_URI, isVideo = false, out = out)
        query(context, MediaStore.Video.Media.EXTERNAL_CONTENT_URI, isVideo = true, out = out)
        out.sortByDescending { it.dateAdded }
        return out
    }

    private fun query(context: Context, collection: Uri, isVideo: Boolean, out: MutableList<LibraryItem>) {
        val projection = if (isVideo) {
            arrayOf(
                MediaStore.MediaColumns._ID,
                MediaStore.MediaColumns.DISPLAY_NAME,
                MediaStore.MediaColumns.DATE_ADDED,
                MediaStore.Video.VideoColumns.DURATION,
            )
        } else {
            arrayOf(
                MediaStore.MediaColumns._ID,
                MediaStore.MediaColumns.DISPLAY_NAME,
                MediaStore.MediaColumns.DATE_ADDED,
            )
        }
        runCatching {
            context.contentResolver.query(
                collection,
                projection,
                null,
                null,
                "${MediaStore.MediaColumns.DATE_ADDED} DESC",
            )?.use { c ->
                val idCol = c.getColumnIndexOrThrow(MediaStore.MediaColumns._ID)
                val nameCol = c.getColumnIndexOrThrow(MediaStore.MediaColumns.DISPLAY_NAME)
                val dateCol = c.getColumnIndexOrThrow(MediaStore.MediaColumns.DATE_ADDED)
                val durCol = if (isVideo) c.getColumnIndexOrThrow(MediaStore.Video.VideoColumns.DURATION) else -1
                while (c.moveToNext()) {
                    val id = c.getLong(idCol)
                    out.add(
                        LibraryItem(
                            uri = ContentUris.withAppendedId(collection, id),
                            isVideo = isVideo,
                            name = c.getString(nameCol) ?: "",
                            durationMs = if (durCol >= 0) c.getLong(durCol) else 0L,
                            dateAdded = c.getLong(dateCol),
                        )
                    )
                }
            }
        }
    }
}

/** Миниатюры и фото для просмотра, без сторонних библиотек. */
object Thumbnails {
    private val cache = object : LruCache<String, Bitmap>(
        ((Runtime.getRuntime().maxMemory() / 1024) / 8).toInt()
    ) {
        override fun sizeOf(key: String, value: Bitmap): Int = value.byteCount / 1024
    }

    fun load(context: Context, uri: Uri): Bitmap? {
        cache.get(uri.toString())?.let { return it }
        val bitmap = runCatching {
            context.contentResolver.loadThumbnail(uri, Size(320, 320), null)
        }.getOrNull()
        if (bitmap != null) cache.put(uri.toString(), bitmap)
        return bitmap
    }

    /** Фото для полноэкранного просмотра, уменьшенное до [maxSide] пикселей по длинной стороне. */
    fun loadPhoto(context: Context, uri: Uri, maxSide: Int = 2048): Bitmap? = runCatching {
        val source = ImageDecoder.createSource(context.contentResolver, uri)
        ImageDecoder.decodeBitmap(source) { decoder, info, _ ->
            val longest = max(info.size.width, info.size.height)
            if (longest > maxSide) decoder.setTargetSampleSize(longest / maxSide)
            decoder.allocator = ImageDecoder.ALLOCATOR_SOFTWARE
        }
    }.getOrNull()
}

fun formatDuration(ms: Long): String {
    val totalSeconds = (ms.coerceAtLeast(0) / 1000)
    val minutes = totalSeconds / 60
    val seconds = totalSeconds % 60
    return "%d:%02d".format(minutes, seconds)
}
