package com.mycut.ultimate

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import com.mycut.ultimate.ui.editor.EditorScreen
import com.mycut.ultimate.ui.home.HomeScreen
import com.mycut.ultimate.ui.library.MediaLibraryScreen
import com.mycut.ultimate.ui.theme.Background
import com.mycut.ultimate.ui.theme.MyCutTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyCutTheme {
                // Состояние навигации переживает пересоздание активности и смерть процесса.
                var openProjectId by rememberSaveable { mutableStateOf<Long?>(null) }
                var showLibrary by rememberSaveable { mutableStateOf(false) }
                BackHandler(enabled = openProjectId != null) { openProjectId = null }

                Box(Modifier.fillMaxSize().background(Background)) {
                    val id = openProjectId
                    when {
                        id != null -> EditorScreen(projectId = id, onBack = { openProjectId = null })
                        showLibrary -> MediaLibraryScreen(onClose = { showLibrary = false })
                        else -> HomeScreen(
                            onOpen = { openProjectId = it },
                            onOpenLibrary = { showLibrary = true },
                        )
                    }
                }
            }
        }
    }
}
