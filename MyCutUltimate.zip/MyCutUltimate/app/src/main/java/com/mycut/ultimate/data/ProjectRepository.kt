package com.mycut.ultimate.data

import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class ProjectRepository(private val dao: ProjectDao) {

    val projects = dao.observeAll()

    suspend fun create(): Long {
        val now = System.currentTimeMillis()
        val title = "Проект " + SimpleDateFormat("dd.MM HH:mm", Locale.getDefault()).format(Date(now))
        return dao.upsert(
            ProjectEntity(
                name = title,
                timelineJson = Timeline().toJson(),
                createdAt = now,
                updatedAt = now,
            )
        )
    }

    suspend fun load(id: Long): ProjectEntity? = dao.get(id)

    suspend fun save(id: Long, timeline: Timeline) {
        val project = dao.get(id) ?: return
        dao.upsert(project.copy(timelineJson = timeline.toJson(), updatedAt = System.currentTimeMillis()))
    }

    suspend fun duplicate(id: Long): Long? {
        val src = dao.get(id) ?: return null
        val now = System.currentTimeMillis()
        return dao.upsert(
            src.copy(
                id = 0,
                name = src.name + " (копия)",
                createdAt = now,
                updatedAt = now,
            )
        )
    }

    suspend fun delete(id: Long) = dao.delete(id)
}
