package com.mycut.ultimate

import android.app.Application
import androidx.room.Room
import com.mycut.ultimate.data.AppDatabase
import com.mycut.ultimate.data.ProjectRepository
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob

class MyCutApp : Application() {

    /** Scope, переживающий экраны: нужен, чтобы сохранение проекта не обрывалось при закрытии редактора. */
    val appScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    val database: AppDatabase by lazy {
        Room.databaseBuilder(this, AppDatabase::class.java, "mycut.db").build()
    }

    val repository: ProjectRepository by lazy { ProjectRepository(database.projectDao()) }
}
