package com.mycut.ultimate.data

import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

/** Фрагмент исходного видео на таймлайне. Время в миллисекундах относительно исходного файла. */
data class Clip(
    val id: String = UUID.randomUUID().toString(),
    val uri: String,
    val name: String,
    val sourceDurationMs: Long,
    val startMs: Long,
    val endMs: Long,
) {
    val durationMs: Long get() = endMs - startMs
}

/** Фильтры, которые реально применяются и в предпросмотре, и при экспорте (см. media/FilterEffects). */
enum class FilterPreset(val label: String) {
    NONE("Без фильтра"),
    BLACK_WHITE("Ч/Б"),
    VIVID("Насыщенный"),
    BRIGHT("Яркий"),
    CONTRAST("Контраст"),
}

/** Ручная цветокоррекция, каждое значение от -1 до 1 (0 — без изменений). */
data class Adjust(
    val brightness: Float = 0f,
    val contrast: Float = 0f,
    val saturation: Float = 0f,
) {
    val isNeutral: Boolean get() = brightness == 0f && contrast == 0f && saturation == 0f

    fun get(index: Int): Float = when (index) {
        0 -> brightness
        1 -> contrast
        else -> saturation
    }

    fun with(index: Int, value: Float): Adjust = when (index) {
        0 -> copy(brightness = value)
        1 -> copy(contrast = value)
        else -> copy(saturation = value)
    }
}

/** Соотношение сторон кадра проекта. ORIGINAL — без изменений. */
enum class AspectPreset(val label: String, val ratio: Float?) {
    ORIGINAL("Оригинал", null),
    R9_16("9:16", 9f / 16f),
    R16_9("16:9", 16f / 9f),
    R1_1("1:1", 1f),
    R4_3("4:3", 4f / 3f),
    R3_4("3:4", 3f / 4f),
}

data class Timeline(
    val clips: List<Clip> = emptyList(),
    val filter: FilterPreset = FilterPreset.NONE,
    val adjust: Adjust = Adjust(),
    val aspect: AspectPreset = AspectPreset.ORIGINAL,
) {
    val totalMs: Long get() = clips.sumOf { it.durationMs }

    /** Переводит глобальную позицию на таймлайне в (индекс клипа, смещение внутри клипа). */
    fun locate(globalMs: Long): Pair<Int, Long>? {
        if (clips.isEmpty()) return null
        var rem = globalMs.coerceAtLeast(0)
        clips.forEachIndexed { i, c ->
            if (rem < c.durationMs) return i to rem
            rem -= c.durationMs
        }
        val last = clips.lastIndex
        return last to clips[last].durationMs
    }

    fun toJson(): String {
        val arr = JSONArray()
        clips.forEach { c ->
            arr.put(
                JSONObject()
                    .put("id", c.id)
                    .put("uri", c.uri)
                    .put("name", c.name)
                    .put("sourceDurationMs", c.sourceDurationMs)
                    .put("startMs", c.startMs)
                    .put("endMs", c.endMs)
            )
        }
        return JSONObject()
            .put("version", 1)
            .put("filter", filter.name)
            .put(
                "adjust",
                JSONObject()
                    .put("brightness", adjust.brightness.toDouble())
                    .put("contrast", adjust.contrast.toDouble())
                    .put("saturation", adjust.saturation.toDouble())
            )
            .put("aspect", aspect.name)
            .put("clips", arr)
            .toString()
    }

    companion object {
        fun fromJson(json: String): Timeline = try {
            val root = JSONObject(json)
            val arr = root.optJSONArray("clips") ?: JSONArray()
            val clips = (0 until arr.length()).map { i ->
                val o = arr.getJSONObject(i)
                Clip(
                    id = o.getString("id"),
                    uri = o.getString("uri"),
                    name = o.optString("name", "Клип"),
                    sourceDurationMs = o.getLong("sourceDurationMs"),
                    startMs = o.getLong("startMs"),
                    endMs = o.getLong("endMs"),
                )
            }
            val filter = runCatching { FilterPreset.valueOf(root.optString("filter", "NONE")) }
                .getOrDefault(FilterPreset.NONE)
            val adjust = root.optJSONObject("adjust")?.let { a ->
                Adjust(
                    brightness = a.optDouble("brightness", 0.0).toFloat().coerceIn(-1f, 1f),
                    contrast = a.optDouble("contrast", 0.0).toFloat().coerceIn(-1f, 1f),
                    saturation = a.optDouble("saturation", 0.0).toFloat().coerceIn(-1f, 1f),
                )
            } ?: Adjust()
            val aspect = runCatching { AspectPreset.valueOf(root.optString("aspect", "ORIGINAL")) }
                .getOrDefault(AspectPreset.ORIGINAL)
            Timeline(clips, filter, adjust, aspect)
        } catch (e: Exception) {
            Timeline()
        }
    }
}
