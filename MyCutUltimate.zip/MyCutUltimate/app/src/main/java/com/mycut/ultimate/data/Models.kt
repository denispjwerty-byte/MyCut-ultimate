package com.mycut.ultimate.data

import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

/** Фрагмент исходного видео на таймлайне. Время в миллисекундах относительно исходного файла. */
data class Clip(
    val id: String = UUID.randomUUID().toString(),
    val uri: String,
    val name: String,
    val sourceDurationMs: Long,
    val startMs: Long,
    val endMs: Long,
) {
    val durationMs: Long get() = endMs - startMs
}

/** Фильтры, которые реально применяются и в предпросмотре, и при экспорте (см. media/FilterEffects). */
enum class FilterPreset(val label: String) {
    NONE("Без фильтра"),
    BLACK_WHITE("Ч/Б"),
    VIVID("Насыщенный"),
    BRIGHT("Яркий"),
    CONTRAST("Контраст"),
}

data class Timeline(
    val clips: List<Clip> = emptyList(),
    val filter: FilterPreset = FilterPreset.NONE,
) {
    val totalMs: Long get() = clips.sumOf { it.durationMs }

    /** Переводит глобальную позицию на таймлайне в (индекс клипа, смещение внутри клипа). */
    fun locate(globalMs: Long): Pair<Int, Long>? {
        if (clips.isEmpty()) return null
        var rem = globalMs.coerceAtLeast(0)
        clips.forEachIndexed { i, c ->
            if (rem < c.durationMs) return i to rem
            rem -= c.durationMs
        }
        val last = clips.lastIndex
        return last to clips[last].durationMs
    }

    fun toJson(): String {
        val arr = JSONArray()
        clips.forEach { c ->
            arr.put(
                JSONObject()
                    .put("id", c.id)
                    .put("uri", c.uri)
                    .put("name", c.name)
                    .put("sourceDurationMs", c.sourceDurationMs)
                    .put("startMs", c.startMs)
                    .put("endMs", c.endMs)
            )
        }
        return JSONObject()
            .put("version", 1)
            .put("filter", filter.name)
            .put("clips", arr)
            .toString()
    }

    companion object {
        fun fromJson(json: String): Timeline = try {
            val root = JSONObject(json)
            val arr = root.optJSONArray("clips") ?: JSONArray()
            val clips = (0 until arr.length()).map { i ->
                val o = arr.getJSONObject(i)
                Clip(
                    id = o.getString("id"),
                    uri = o.getString("uri"),
                    name = o.optString("name", "Клип"),
                    sourceDurationMs = o.getLong("sourceDurationMs"),
                    startMs = o.getLong("startMs"),
                    endMs = o.getLong("endMs"),
                )
            }
            val filter = runCatching { FilterPreset.valueOf(root.optString("filter", "NONE")) }
                .getOrDefault(FilterPreset.NONE)
            Timeline(clips, filter)
        } catch (e: Exception) {
            Timeline()
        }
    }
}
