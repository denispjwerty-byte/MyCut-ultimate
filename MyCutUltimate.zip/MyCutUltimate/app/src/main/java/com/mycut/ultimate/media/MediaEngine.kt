package com.mycut.ultimate.media

import androidx.core.net.toUri
import androidx.media3.common.Effect
import androidx.media3.common.MediaItem
import androidx.media3.effect.Brightness
import androidx.media3.effect.Contrast
import androidx.media3.effect.HslAdjustment
import androidx.media3.effect.RgbFilter
import com.mycut.ultimate.data.Clip
import com.mycut.ultimate.data.FilterPreset

/** Клип с учётом обрезки как MediaItem (используется и в предпросмотре, и в экспорте). */
fun Clip.toMediaItem(): MediaItem =
    MediaItem.Builder()
        .setUri(uri.toUri())
        .setClippingConfiguration(
            MediaItem.ClippingConfiguration.Builder()
                .setStartPositionMs(startMs)
                .setEndPositionMs(endMs)
                .build()
        )
        .build()

/** Видеоэффекты Media3 (OpenGL ES). Один и тот же список идёт в ExoPlayer и в Transformer. */
object FilterEffects {
    fun build(filter: FilterPreset): List<Effect> = when (filter) {
        FilterPreset.NONE -> emptyList()
        FilterPreset.BLACK_WHITE -> listOf(RgbFilter.createGrayscaleFilter())
        FilterPreset.VIVID -> listOf(HslAdjustment.Builder().adjustSaturation(40f).build())
        FilterPreset.BRIGHT -> listOf(Brightness(0.15f))
        FilterPreset.CONTRAST -> listOf(Contrast(0.3f))
    }
}

enum class ExportQuality(val label: String, val height: Int?) {
    P720("720p", 720),
    P1080("1080p", 1080),
    ORIGINAL("Как в исходнике", null),
}
