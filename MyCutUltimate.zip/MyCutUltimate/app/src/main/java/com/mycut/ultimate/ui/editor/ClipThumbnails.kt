package com.mycut.ultimate.ui.editor

import android.graphics.Bitmap
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.util.LruCache
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.remember
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import com.mycut.ultimate.data.Clip
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext

/** Кэш кадров в памяти: ключ — uri клипа и время кадра с точностью до 200 мс. */
private object ThumbCache {
    val cache = LruCache<String, Bitmap>(120)
}

private const val THUMB_HEIGHT_PX = 120

/**
 * Возвращает [count] кадров клипа, равномерно распределённых по его обрезанной длине.
 * Список заполняется по мере декодирования: пока кадр не готов, элемент равен null.
 */
@Composable
fun rememberClipThumbnails(clip: Clip, count: Int): List<ImageBitmap?> {
    val context = LocalContext.current
    val thumbs = remember(clip.uri, clip.startMs, clip.endMs, count) {
        mutableStateListOf<ImageBitmap?>().apply { repeat(count) { add(null) } }
    }
    LaunchedEffect(clip.uri, clip.startMs, clip.endMs, count) {
        withContext(Dispatchers.IO) {
            val retriever = MediaMetadataRetriever()
            try {
                retriever.setDataSource(context, Uri.parse(clip.uri))
                var w = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)
                    ?.toIntOrNull() ?: 16
                var h = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)
                    ?.toIntOrNull() ?: 9
                val rotation = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION)
                    ?.toIntOrNull() ?: 0
                if (rotation == 90 || rotation == 270) {
                    val t = w; w = h; h = t
                }
                val dstW = (THUMB_HEIGHT_PX * w.toFloat() / h.coerceAtLeast(1)).toInt().coerceIn(40, 400)

                for (i in 0 until count) {
                    ensureActive()
                    val timeMs = clip.startMs + clip.durationMs * (2L * i + 1) / (2L * count)
                    val key = "${clip.uri}@${timeMs / 200}"
                    val bmp = ThumbCache.cache.get(key)
                        ?: retriever.getScaledFrameAtTime(
                            timeMs * 1000,
                            MediaMetadataRetriever.OPTION_CLOSEST_SYNC,
                            dstW,
                            THUMB_HEIGHT_PX,
                        )?.also { ThumbCache.cache.put(key, it) }
                    if (bmp != null && i < thumbs.size) thumbs[i] = bmp.asImageBitmap()
                }
            } catch (e: Exception) {
                // Не удалось прочитать кадры — остаются тёмные плитки, монтаж не страдает.
            } finally {
                runCatching { retriever.release() }
            }
        }
    }
    return thumbs
}
