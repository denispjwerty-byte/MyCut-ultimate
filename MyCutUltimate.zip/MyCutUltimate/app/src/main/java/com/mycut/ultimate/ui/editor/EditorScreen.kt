package com.mycut.ultimate.ui.editor

import android.app.Application
import android.content.Intent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.RadioButton
import androidx.compose.material3.RangeSlider
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import com.mycut.ultimate.data.Clip
import com.mycut.ultimate.data.FilterPreset
import com.mycut.ultimate.media.ExportQuality
import com.mycut.ultimate.media.FilterEffects
import com.mycut.ultimate.media.toMediaItem
import com.mycut.ultimate.ui.library.MediaLibraryScreen
import com.mycut.ultimate.ui.theme.Accent
import com.mycut.ultimate.ui.theme.SurfaceHigh
import kotlinx.coroutines.delay

@Composable
fun EditorScreen(projectId: Long, onBack: () -> Unit) {
    val context = LocalContext.current
    val app = context.applicationContext as Application
    val vm = viewModel<EditorViewModel>(
        key = "editor_$projectId",
        factory = EditorViewModelFactory(app, projectId),
    )
    val state by vm.state.collectAsStateWithLifecycle()
    val export by vm.export.collectAsStateWithLifecycle()
    val timeline = state.timeline
    val clips = timeline.clips
    val selected = state.selectedClip

    val exo = remember { ExoPlayer.Builder(context).build() }
    var isPlaying by remember { mutableStateOf(false) }
    var playheadMs by remember { mutableLongStateOf(0L) }
    var dpPerSec by remember { mutableFloatStateOf(40f) }
    var showExportDialog by remember { mutableStateOf(false) }
    var showLibrary by remember { mutableStateOf(false) }
    var quality by remember { mutableStateOf(ExportQuality.P1080) }
    val snackbar = remember { SnackbarHostState() }

    DisposableEffect(exo) {
        val listener = object : Player.Listener {
            override fun onIsPlayingChanged(isPlayingNow: Boolean) {
                isPlaying = isPlayingNow
            }
        }
        exo.addListener(listener)
        onDispose {
            exo.removeListener(listener)
            exo.release()
        }
    }
    DisposableEffect(Unit) { onDispose { vm.saveNow() } }
    LifecycleEventEffect(Lifecycle.Event.ON_STOP) {
        vm.saveNow()
        exo.pause()
    }

    fun seekTo(ms: Long) {
        val loc = timeline.locate(ms) ?: return
        exo.seekTo(loc.first, loc.second)
        playheadMs = ms.coerceIn(0, timeline.totalMs)
    }

    // Фильтр применяется в предпросмотре тем же набором GL-эффектов, что и при экспорте.
    LaunchedEffect(timeline.filter) { exo.setVideoEffects(FilterEffects.build(timeline.filter)) }

    // Пересобираем плейлист предпросмотра при любом изменении состава/обрезки клипов.
    val mediaKey = clips.map { Triple(it.uri, it.startMs, it.endMs) }
    LaunchedEffect(mediaKey) {
        if (clips.isEmpty()) {
            exo.clearMediaItems()
            playheadMs = 0
        } else {
            val keep = playheadMs
            exo.setMediaItems(clips.map { it.toMediaItem() })
            exo.prepare()
            seekTo(keep)
        }
    }

    // Позиция курсора на общем таймлайне.
    LaunchedEffect(exo, clips) {
        while (true) {
            if (clips.isNotEmpty() && exo.mediaItemCount == clips.size) {
                val idx = exo.currentMediaItemIndex.coerceIn(0, clips.lastIndex)
                val base = clips.take(idx).sumOf { it.durationMs }
                playheadMs = base + exo.currentPosition.coerceIn(0, clips[idx].durationMs)
            }
            delay(60)
        }
    }

    LaunchedEffect(state.message) {
        state.message?.let {
            snackbar.showSnackbar(it)
            vm.consumeMessage()
        }
    }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        vm.addMedia(uris)
    }

    Box(Modifier.fillMaxSize()) {
        Column(
            Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding()
        ) {
            // ---- верхняя панель ----
            Row(
                Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 4.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                TextButton(onClick = onBack) { Text("←", fontSize = 20.sp) }
                Text(
                    state.name,
                    modifier = Modifier.weight(1f),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    style = MaterialTheme.typography.titleSmall,
                )
                TextButton(onClick = vm::undo, enabled = state.canUndo) { Text("↶", fontSize = 20.sp) }
                TextButton(onClick = vm::redo, enabled = state.canRedo) { Text("↷", fontSize = 20.sp) }
                Button(
                    onClick = { showExportDialog = true },
                    enabled = clips.isNotEmpty() && !state.importing,
                    contentPadding = PaddingValues(horizontal = 14.dp, vertical = 6.dp),
                ) { Text("Экспорт") }
            }

            // ---- предпросмотр ----
            Box(
                Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .heightIn(min = 160.dp)
                    .background(Color.Black),
                contentAlignment = Alignment.Center,
            ) {
                AndroidView(
                    factory = { ctx ->
                        PlayerView(ctx).apply {
                            player = exo
                            useController = false
                        }
                    },
                    modifier = Modifier.fillMaxSize(),
                )
                if (clips.isEmpty()) {
                    Text(
                        "Добавьте видео кнопкой «＋ Медиатека»",
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }

            // ---- управление воспроизведением ----
            val maxMs = timeline.totalMs.toFloat().coerceAtLeast(1f)
            Row(
                Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                TextButton(
                    onClick = {
                        if (isPlaying) {
                            exo.pause()
                        } else {
                            if (exo.playbackState == Player.STATE_ENDED) seekTo(0)
                            exo.play()
                        }
                    },
                    enabled = clips.isNotEmpty(),
                ) { Text(if (isPlaying) "⏸" else "▶", fontSize = 20.sp) }
                Text(
                    "${formatTime(playheadMs)} / ${formatTime(timeline.totalMs)}",
                    style = MaterialTheme.typography.bodySmall,
                )
                Slider(
                    value = playheadMs.toFloat().coerceIn(0f, maxMs),
                    onValueChange = { seekTo(it.toLong()) },
                    valueRange = 0f..maxMs,
                    enabled = clips.isNotEmpty(),
                    modifier = Modifier
                        .weight(1f)
                        .padding(start = 8.dp),
                )
            }

            // ---- нижняя панель: таймлайн, инструменты, обрезка, фильтры ----
            Column(
                Modifier
                    .fillMaxWidth()
                    .heightIn(max = 340.dp)
                    .verticalScroll(rememberScrollState())
                    .background(MaterialTheme.colorScheme.surface)
                    .padding(vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                if (clips.isEmpty()) {
                    Box(
                        Modifier
                            .fillMaxWidth()
                            .height(76.dp),
                        contentAlignment = Alignment.Center,
                    ) {
                        Text("Таймлайн пуст", color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                } else {
                    TimelineView(
                        clips = clips,
                        selectedId = state.selectedClipId,
                        playheadMs = playheadMs,
                        dpPerSec = dpPerSec,
                        isPlaying = isPlaying,
                        onTap = { index, globalMs ->
                            vm.selectClip(clips[index].id)
                            seekTo(globalMs)
                        },
                    )
                }

                Row(
                    Modifier
                        .horizontalScroll(rememberScrollState())
                        .padding(horizontal = 8.dp),
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                ) {
                    ToolButton("＋ Медиатека", enabled = !state.importing) {
                        exo.pause()
                        showLibrary = true
                    }
                    ToolButton("＋ Из файлов", enabled = !state.importing) { picker.launch(arrayOf("video/*")) }
                    ToolButton("✂ Разделить", enabled = clips.isNotEmpty()) { vm.splitAt(playheadMs) }
                    ToolButton("Удалить", enabled = selected != null) { vm.deleteSelected() }
                    ToolButton("Копия", enabled = selected != null) { vm.duplicateSelected() }
                    ToolButton("← клип", enabled = selected != null) { vm.moveSelected(-1) }
                    ToolButton("клип →", enabled = selected != null) { vm.moveSelected(1) }
                    ToolButton("− масштаб", enabled = clips.isNotEmpty()) {
                        dpPerSec = (dpPerSec / 1.5f).coerceAtLeast(8f)
                    }
                    ToolButton("+ масштаб", enabled = clips.isNotEmpty()) {
                        dpPerSec = (dpPerSec * 1.5f).coerceAtMost(240f)
                    }
                }

                if (selected != null) {
                    TrimPanel(clip = selected, onTrim = vm::trimSelected)
                }

                Row(
                    Modifier
                        .horizontalScroll(rememberScrollState())
                        .padding(horizontal = 8.dp),
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                ) {
                    FilterPreset.entries.forEach { f ->
                        FilterChip(
                            selected = timeline.filter == f,
                            onClick = { vm.setFilter(f) },
                            label = { Text(f.label) },
                            enabled = clips.isNotEmpty(),
                        )
                    }
                }
            }
        }

        SnackbarHost(
            snackbar,
            Modifier
                .align(Alignment.BottomCenter)
                .navigationBarsPadding(),
        )
        if (state.importing || !state.loaded) {
            CircularProgressIndicator(Modifier.align(Alignment.Center))
        }
        if (showLibrary) {
            MediaLibraryScreen(
                onClose = { showLibrary = false },
                onAddVideos = { uris ->
                    vm.addMedia(uris)
                    showLibrary = false
                },
            )
        }
    }

    // ---- диалоги экспорта ----
    if (showExportDialog) {
        AlertDialog(
            onDismissRequest = { showExportDialog = false },
            title = { Text("Экспорт в MP4") },
            text = {
                Column {
                    Text("H.264 + AAC, без водяных знаков. Файл появится в галерее (Movies/MyCut).")
                    Text(
                        "Разрешение:",
                        modifier = Modifier.padding(top = 12.dp),
                        style = MaterialTheme.typography.labelLarge,
                    )
                    ExportQuality.entries.forEach { q ->
                        Row(
                            Modifier
                                .fillMaxWidth()
                                .clickable { quality = q },
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            RadioButton(selected = quality == q, onClick = { quality = q })
                            Text(q.label)
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    showExportDialog = false
                    vm.startExport(quality)
                }) { Text("Начать") }
            },
            dismissButton = { TextButton(onClick = { showExportDialog = false }) { Text("Отмена") } },
        )
    }

    when (val e = export) {
        ExportState.Idle -> Unit
        is ExportState.Running -> AlertDialog(
            onDismissRequest = {},
            title = { Text("Экспорт…") },
            text = {
                Column {
                    LinearProgressIndicator(progress = { e.progress }, modifier = Modifier.fillMaxWidth())
                    Text(
                        "${(e.progress * 100).toInt()}%",
                        modifier = Modifier.padding(top = 8.dp),
                        style = MaterialTheme.typography.bodySmall,
                    )
                }
            },
            confirmButton = { TextButton(onClick = vm::cancelExport) { Text("Отменить") } },
        )
        is ExportState.Done -> AlertDialog(
            onDismissRequest = vm::dismissExport,
            title = { Text("Готово") },
            text = { Text("Видео сохранено в галерею (Movies/MyCut).") },
            confirmButton = {
                TextButton(onClick = {
                    runCatching {
                        context.startActivity(
                            Intent(Intent.ACTION_VIEW)
                                .setDataAndType(e.uri, "video/mp4")
                                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
                        )
                    }
                    vm.dismissExport()
                }) { Text("Открыть") }
            },
            dismissButton = { TextButton(onClick = vm::dismissExport) { Text("Закрыть") } },
        )
        is ExportState.Failed -> AlertDialog(
            onDismissRequest = vm::dismissExport,
            title = { Text("Ошибка экспорта") },
            text = { Text(e.message) },
            confirmButton = { TextButton(onClick = vm::dismissExport) { Text("OK") } },
        )
    }
}

@Composable
private fun ToolButton(label: String, enabled: Boolean = true, onClick: () -> Unit) {
    OutlinedButton(
        onClick = onClick,
        enabled = enabled,
        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
    ) { Text(label, style = MaterialTheme.typography.labelMedium) }
}

@Composable
private fun TimelineView(
    clips: List<Clip>,
    selectedId: String?,
    playheadMs: Long,
    dpPerSec: Float,
    isPlaying: Boolean,
    onTap: (clipIndex: Int, globalMs: Long) -> Unit,
) {
    val scroll = rememberScrollState()
    val density = LocalDensity.current
    val currentOnTap by rememberUpdatedState(onTap)

    BoxWithConstraints(
        Modifier
            .fillMaxWidth()
            .height(76.dp)
    ) {
        val viewPx = constraints.maxWidth
        val playheadPx = (playheadMs / 1000f * dpPerSec * density.density).toInt()
        // Во время воспроизведения удерживаем курсор в центре видимой области.
        LaunchedEffect(playheadPx, isPlaying) {
            if (isPlaying) scroll.scrollTo((playheadPx - viewPx / 2).coerceAtLeast(0))
        }

        Box(
            Modifier
                .fillMaxSize()
                .horizontalScroll(scroll)
        ) {
            Row {
                var startOffsetMs = 0L
                clips.forEachIndexed { i, c ->
                    val clipStart = startOffsetMs
                    startOffsetMs += c.durationMs
                    val isSelected = c.id == selectedId
                    val width = (c.durationMs / 1000f * dpPerSec).dp.coerceAtLeast(24.dp)
                    Box(
                        Modifier
                            .width(width)
                            .fillMaxHeight()
                            .padding(1.dp)
                            .clip(RoundedCornerShape(6.dp))
                            .background(if (isSelected) Accent.copy(alpha = 0.30f) else SurfaceHigh)
                            .border(
                                width = if (isSelected) 2.dp else 1.dp,
                                color = if (isSelected) Accent else Color(0xFF3A3E49),
                                shape = RoundedCornerShape(6.dp),
                            )
                            .pointerInput(c.id, dpPerSec, clipStart) {
                                detectTapGestures { offset ->
                                    val inClip = (offset.x / density.density / dpPerSec * 1000f).toLong()
                                        .coerceIn(0, (c.durationMs - 1).coerceAtLeast(0))
                                    currentOnTap(i, clipStart + inClip)
                                }
                            }
                            .padding(6.dp)
                    ) {
                        Column {
                            Text(
                                c.name,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                                style = MaterialTheme.typography.labelSmall,
                            )
                            Text(
                                formatTime(c.durationMs),
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                        }
                    }
                }
            }
            // Курсор воспроизведения
            Box(
                Modifier
                    .offset(x = (playheadMs / 1000f * dpPerSec).dp)
                    .width(2.dp)
                    .fillMaxHeight()
                    .background(Color.White)
            )
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun TrimPanel(clip: Clip, onTrim: (Long, Long) -> Unit) {
    var range by remember(clip.id, clip.startMs, clip.endMs) {
        mutableStateOf(clip.startMs.toFloat()..clip.endMs.toFloat())
    }
    Column(Modifier.padding(horizontal = 12.dp)) {
        Text(
            "Обрезка: ${formatTime(range.start.toLong())} – ${formatTime(range.endInclusive.toLong())}" +
                "  (длина ${formatTime((range.endInclusive - range.start).toLong())})",
            style = MaterialTheme.typography.bodySmall,
        )
        RangeSlider(
            value = range,
            onValueChange = { range = it },
            valueRange = 0f..clip.sourceDurationMs.toFloat(),
            onValueChangeFinished = { onTrim(range.start.toLong(), range.endInclusive.toLong()) },
        )
    }
}

private fun formatTime(ms: Long): String {
    val total = ms.coerceAtLeast(0)
    val minutes = total / 60_000
    val seconds = (total / 1000) % 60
    val tenths = (total / 100) % 10
    return "%d:%02d.%d".format(minutes, seconds, tenths)
}
