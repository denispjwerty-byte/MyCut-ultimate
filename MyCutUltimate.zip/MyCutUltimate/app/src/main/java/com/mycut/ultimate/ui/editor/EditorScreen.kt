package com.mycut.ultimate.ui.editor

import android.app.Application
import android.content.Intent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.animateContentSize
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.calculateZoom
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.wrapContentWidth
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Redo
import androidx.compose.material.icons.automirrored.filled.Undo
import androidx.compose.material.icons.outlined.Add
import androidx.compose.material.icons.outlined.AspectRatio
import androidx.compose.material.icons.outlined.AutoFixHigh
import androidx.compose.material.icons.outlined.Check
import androidx.compose.material.icons.outlined.ChevronLeft
import androidx.compose.material.icons.outlined.ChevronRight
import androidx.compose.material.icons.outlined.Close
import androidx.compose.material.icons.outlined.Contrast
import androidx.compose.material.icons.outlined.ContentCopy
import androidx.compose.material.icons.outlined.ContentCut
import androidx.compose.material.icons.outlined.Crop
import androidx.compose.material.icons.outlined.Delete
import androidx.compose.material.icons.outlined.Folder
import androidx.compose.material.icons.outlined.KeyboardArrowDown
import androidx.compose.material.icons.outlined.Palette
import androidx.compose.material.icons.outlined.Pause
import androidx.compose.material.icons.outlined.PlayArrow
import androidx.compose.material.icons.outlined.Refresh
import androidx.compose.material.icons.outlined.Tune
import androidx.compose.material.icons.outlined.VideoLibrary
import androidx.compose.material.icons.outlined.WbSunny
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.RangeSlider
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import com.mycut.ultimate.data.Adjust
import com.mycut.ultimate.data.AspectPreset
import com.mycut.ultimate.data.Clip
import com.mycut.ultimate.data.FilterPreset
import com.mycut.ultimate.media.ExportQuality
import com.mycut.ultimate.media.FilterEffects
import com.mycut.ultimate.media.toMediaItem
import com.mycut.ultimate.ui.library.MediaLibraryScreen
import com.mycut.ultimate.ui.theme.Accent
import com.mycut.ultimate.ui.theme.SurfaceHigh
import kotlinx.coroutines.delay
import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.roundToInt

private enum class Panel { NONE, FILTERS, ADJUST, ASPECT, TRIM }

private val RibbonBg = Color(0xFF16181D)
private val Muted = Color(0xFF8D93A1)

@Composable
fun EditorScreen(projectId: Long, onBack: () -> Unit) {
    val context = LocalContext.current
    val app = context.applicationContext as Application
    val vm = viewModel<EditorViewModel>(
        key = "editor_$projectId",
        factory = EditorViewModelFactory(app, projectId),
    )
    val state by vm.state.collectAsStateWithLifecycle()
    val export by vm.export.collectAsStateWithLifecycle()
    val timeline = state.timeline
    val clips = timeline.clips
    val selected = state.selectedClip

    val exo = remember { ExoPlayer.Builder(context).build() }
    var isPlaying by remember { mutableStateOf(false) }
    var playheadMs by remember { mutableLongStateOf(0L) }
    var dpPerSec by remember { mutableFloatStateOf(48f) }
    var showLibrary by remember { mutableStateOf(false) }
    var quality by remember { mutableStateOf(ExportQuality.P1080) }
    var qualityMenu by remember { mutableStateOf(false) }
    var panel by remember { mutableStateOf(Panel.NONE) }
    var liveAdjust by remember { mutableStateOf<Adjust?>(null) }
    val snackbar = remember { SnackbarHostState() }

    // Панель обрезки имеет смысл только пока выбран клип.
    val activePanel = if (panel == Panel.TRIM && selected == null) Panel.NONE else panel
    LaunchedEffect(selected == null) {
        if (selected == null && panel == Panel.TRIM) panel = Panel.NONE
    }

    DisposableEffect(exo) {
        val listener = object : Player.Listener {
            override fun onIsPlayingChanged(isPlayingNow: Boolean) {
                isPlaying = isPlayingNow
            }
        }
        exo.addListener(listener)
        onDispose {
            exo.removeListener(listener)
            exo.release()
        }
    }
    DisposableEffect(Unit) { onDispose { vm.saveNow() } }
    LifecycleEventEffect(Lifecycle.Event.ON_STOP) {
        vm.saveNow()
        exo.pause()
    }

    fun seekTo(ms: Long) {
        val loc = timeline.locate(ms) ?: return
        exo.seekTo(loc.first, loc.second)
        playheadMs = ms.coerceIn(0, timeline.totalMs)
    }

    // Фильтр, ручная коррекция и формат кадра применяются в предпросмотре тем же набором
    // GL-эффектов, что и при экспорте. Небольшая задержка гасит лишние пересборки при перетаскивании ползунка.
    val effectiveAdjust = liveAdjust ?: timeline.adjust
    LaunchedEffect(timeline.filter, effectiveAdjust, timeline.aspect) {
        delay(60)
        exo.setVideoEffects(FilterEffects.build(timeline.filter, effectiveAdjust, timeline.aspect))
    }

    // Пересобираем плейлист предпросмотра при любом изменении состава/обрезки клипов.
    val mediaKey = clips.map { Triple(it.uri, it.startMs, it.endMs) }
    LaunchedEffect(mediaKey) {
        if (clips.isEmpty()) {
            exo.clearMediaItems()
            playheadMs = 0
        } else {
            val keep = playheadMs
            exo.setMediaItems(clips.map { it.toMediaItem() })
            exo.prepare()
            seekTo(keep)
        }
    }

    // Позиция курсора на общем таймлайне.
    LaunchedEffect(exo, clips) {
        while (true) {
            if (clips.isNotEmpty() && exo.mediaItemCount == clips.size) {
                val idx = exo.currentMediaItemIndex.coerceIn(0, clips.lastIndex)
                val base = clips.take(idx).sumOf { it.durationMs }
                playheadMs = base + exo.currentPosition.coerceIn(0, clips[idx].durationMs)
            }
            delay(60)
        }
    }

    LaunchedEffect(state.message) {
        state.message?.let {
            snackbar.showSnackbar(it)
            vm.consumeMessage()
        }
    }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        vm.addMedia(uris)
    }

    fun openLibrary() {
        exo.pause()
        showLibrary = true
    }

    Box(
        Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        Column(
            Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding()
        ) {
            // ---- верхняя панель ----
            Row(
                Modifier
                    .fillMaxWidth()
                    .height(56.dp)
                    .padding(horizontal = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                IconButton(onClick = onBack) { Icon(Icons.Outlined.Close, contentDescription = "Закрыть") }
                Text(
                    state.name,
                    modifier = Modifier
                        .weight(1f)
                        .padding(horizontal = 8.dp),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    style = MaterialTheme.typography.titleSmall,
                    color = Muted,
                )
                Box {
                    Row(
                        Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .background(SurfaceHigh)
                            .clickable { qualityMenu = true }
                            .padding(start = 12.dp, end = 6.dp, top = 8.dp, bottom = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Text(quality.label, fontWeight = androidx.compose.ui.text.font.FontWeight.Bold)
                        Icon(Icons.Outlined.KeyboardArrowDown, contentDescription = null, modifier = Modifier.size(18.dp))
                    }
                    DropdownMenu(expanded = qualityMenu, onDismissRequest = { qualityMenu = false }) {
                        ExportQuality.entries.forEach { q ->
                            DropdownMenuItem(
                                text = { Text(q.label) },
                                onClick = {
                                    quality = q
                                    qualityMenu = false
                                },
                            )
                        }
                    }
                }
                Spacer(Modifier.width(8.dp))
                Button(
                    onClick = {
                        exo.pause()
                        vm.startExport(quality)
                    },
                    enabled = clips.isNotEmpty() && !state.importing,
                    shape = RoundedCornerShape(8.dp),
                    contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
                ) { Text("Экспорт", fontWeight = androidx.compose.ui.text.font.FontWeight.Bold) }
            }

            // ---- предпросмотр ----
            Box(
                Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .heightIn(min = 120.dp)
                    .background(Color.Black),
                contentAlignment = Alignment.Center,
            ) {
                AndroidView(
                    factory = { ctx ->
                        PlayerView(ctx).apply {
                            player = exo
                            useController = false
                        }
                    },
                    modifier = Modifier.fillMaxSize(),
                )
                if (clips.isEmpty() && state.loaded) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Box(
                            Modifier
                                .size(64.dp)
                                .clip(CircleShape)
                                .background(Accent)
                                .clickable(enabled = !state.importing) { openLibrary() },
                            contentAlignment = Alignment.Center,
                        ) {
                            Icon(Icons.Outlined.Add, contentDescription = "Добавить видео", tint = Color.Black, modifier = Modifier.size(32.dp))
                        }
                        Text(
                            "Добавьте видео",
                            modifier = Modifier.padding(top = 12.dp),
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                }
            }

            // ---- время, воспроизведение, отмена и повтор ----
            Row(
                Modifier
                    .fillMaxWidth()
                    .height(48.dp)
                    .padding(horizontal = 12.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text(
                    "${formatClock(playheadMs)} / ${formatClock(timeline.totalMs)}",
                    modifier = Modifier.weight(1f),
                    style = MaterialTheme.typography.bodySmall,
                )
                IconButton(
                    onClick = {
                        if (isPlaying) {
                            exo.pause()
                        } else {
                            if (exo.playbackState == Player.STATE_ENDED) seekTo(0)
                            exo.play()
                        }
                    },
                    enabled = clips.isNotEmpty(),
                ) {
                    Icon(
                        if (isPlaying) Icons.Outlined.Pause else Icons.Outlined.PlayArrow,
                        contentDescription = if (isPlaying) "Пауза" else "Воспроизвести",
                        modifier = Modifier.size(30.dp),
                    )
                }
                Row(Modifier.weight(1f), horizontalArrangement = Arrangement.End) {
                    IconButton(onClick = vm::undo, enabled = state.canUndo) {
                        Icon(Icons.AutoMirrored.Filled.Undo, contentDescription = "Отменить")
                    }
                    IconButton(onClick = vm::redo, enabled = state.canRedo) {
                        Icon(Icons.AutoMirrored.Filled.Redo, contentDescription = "Повторить")
                    }
                }
            }

            // ---- таймлайн ----
            TimelineView(
                clips = clips,
                selectedId = state.selectedClipId,
                playheadMs = playheadMs,
                totalMs = timeline.totalMs,
                dpPerSec = dpPerSec,
                onSelect = { id -> vm.selectClip(if (id == state.selectedClipId) null else id) },
                onUserSeek = { ms ->
                    if (exo.isPlaying) exo.pause()
                    seekTo(ms)
                },
                onZoom = { factor -> dpPerSec = (dpPerSec * factor).coerceIn(8f, 240f) },
                onAdd = ::openLibrary,
                addEnabled = !state.importing,
            )

            // ---- нижняя область: панель инструментов или открытая панель настроек ----
            Box(
                Modifier
                    .fillMaxWidth()
                    .animateContentSize()
            ) {
                when (activePanel) {
                    Panel.NONE -> {
                        if (selected == null) {
                            Ribbon(
                                items = listOf(
                                    RibbonItem(Icons.Outlined.VideoLibrary, "Медиатека", !state.importing) { openLibrary() },
                                    RibbonItem(Icons.Outlined.Folder, "Файлы", !state.importing) { picker.launch(arrayOf("video/*")) },
                                    RibbonItem(Icons.Outlined.ContentCut, "Разделить", clips.isNotEmpty()) { vm.splitAt(playheadMs) },
                                    RibbonItem(Icons.Outlined.AutoFixHigh, "Фильтры", clips.isNotEmpty()) { panel = Panel.FILTERS },
                                    RibbonItem(Icons.Outlined.Tune, "Настроить", clips.isNotEmpty()) { panel = Panel.ADJUST },
                                    RibbonItem(Icons.Outlined.AspectRatio, "Формат", clips.isNotEmpty()) { panel = Panel.ASPECT },
                                ),
                            )
                        } else {
                            Ribbon(
                                onBack = { vm.selectClip(null) },
                                items = listOf(
                                    RibbonItem(Icons.Outlined.ContentCut, "Разделить") { vm.splitAt(playheadMs) },
                                    RibbonItem(Icons.Outlined.Crop, "Обрезка") { panel = Panel.TRIM },
                                    RibbonItem(Icons.Outlined.ContentCopy, "Создать копию") { vm.duplicateSelected() },
                                    RibbonItem(Icons.Outlined.ChevronLeft, "Влево") { vm.moveSelected(-1) },
                                    RibbonItem(Icons.Outlined.ChevronRight, "Вправо") { vm.moveSelected(1) },
                                    RibbonItem(Icons.Outlined.Delete, "Удалить") { vm.deleteSelected() },
                                    RibbonItem(Icons.Outlined.AutoFixHigh, "Фильтры") { panel = Panel.FILTERS },
                                    RibbonItem(Icons.Outlined.Tune, "Настроить") { panel = Panel.ADJUST },
                                    RibbonItem(Icons.Outlined.AspectRatio, "Формат") { panel = Panel.ASPECT },
                                ),
                            )
                        }
                    }

                    Panel.FILTERS, Panel.ADJUST -> PanelFrame(
                        header = {
                            PanelTab("Фильтры", activePanel == Panel.FILTERS) { panel = Panel.FILTERS }
                            PanelTab("Настроить", activePanel == Panel.ADJUST) { panel = Panel.ADJUST }
                        },
                        onDone = { panel = Panel.NONE },
                    ) {
                        if (activePanel == Panel.FILTERS) {
                            FilterRow(current = timeline.filter, onPick = vm::setFilter)
                        } else {
                            AdjustPanel(
                                adjust = timeline.adjust,
                                onLive = { liveAdjust = it },
                                onCommit = vm::setAdjust,
                            )
                        }
                    }

                    Panel.ASPECT -> PanelFrame(
                        header = { PanelTitle("Соотношение сторон") },
                        onDone = { panel = Panel.NONE },
                    ) {
                        AspectRow(current = timeline.aspect, onPick = vm::setAspect)
                    }

                    Panel.TRIM -> PanelFrame(
                        header = { PanelTitle("Обрезка") },
                        onDone = { panel = Panel.NONE },
                    ) {
                        selected?.let { TrimPanel(clip = it, onTrim = vm::trimSelected) }
                    }
                }
            }
        }

        SnackbarHost(
            snackbar,
            Modifier
                .align(Alignment.BottomCenter)
                .navigationBarsPadding(),
        )
        if (state.importing || !state.loaded) {
            CircularProgressIndicator(Modifier.align(Alignment.Center))
        }
        if (showLibrary) {
            MediaLibraryScreen(
                onClose = { showLibrary = false },
                onAddVideos = { uris ->
                    vm.addMedia(uris)
                    showLibrary = false
                },
            )
        }
    }

    // ---- диалоги экспорта ----
    when (val e = export) {
        ExportState.Idle -> Unit
        is ExportState.Running -> AlertDialog(
            onDismissRequest = {},
            title = { Text("Экспорт…") },
            text = {
                Column {
                    LinearProgressIndicator(progress = { e.progress }, modifier = Modifier.fillMaxWidth())
                    Text(
                        "${(e.progress * 100).toInt()}%",
                        modifier = Modifier.padding(top = 8.dp),
                        style = MaterialTheme.typography.bodySmall,
                    )
                }
            },
            confirmButton = { TextButton(onClick = vm::cancelExport) { Text("Отменить") } },
        )
        is ExportState.Done -> AlertDialog(
            onDismissRequest = vm::dismissExport,
            title = { Text("Готово") },
            text = { Text("Видео сохранено в галерею (Movies/MyCut), без водяных знаков.") },
            confirmButton = {
                TextButton(onClick = {
                    runCatching {
                        context.startActivity(
                            Intent(Intent.ACTION_VIEW)
                                .setDataAndType(e.uri, "video/mp4")
                                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
                        )
                    }
                    vm.dismissExport()
                }) { Text("Открыть") }
            },
            dismissButton = { TextButton(onClick = vm::dismissExport) { Text("Закрыть") } },
        )
        is ExportState.Failed -> AlertDialog(
            onDismissRequest = vm::dismissExport,
            title = { Text("Ошибка экспорта") },
            text = { Text(e.message) },
            confirmButton = { TextButton(onClick = vm::dismissExport) { Text("OK") } },
        )
    }
}

// ---------------------------------------------------------------------------------------------
// Нижняя лента инструментов
// ---------------------------------------------------------------------------------------------

private data class RibbonItem(
    val icon: ImageVector,
    val label: String,
    val enabled: Boolean = true,
    val onClick: () -> Unit,
)

@Composable
private fun Ribbon(items: List<RibbonItem>, onBack: (() -> Unit)? = null) {
    Row(
        Modifier
            .fillMaxWidth()
            .background(RibbonBg)
            .padding(vertical = 8.dp)
            .horizontalScroll(rememberScrollState())
            .padding(horizontal = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        if (onBack != null) {
            Box(
                Modifier
                    .padding(end = 6.dp)
                    .size(width = 44.dp, height = 60.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(SurfaceHigh)
                    .clickable(onClick = onBack),
                contentAlignment = Alignment.Center,
            ) { Icon(Icons.Outlined.ChevronLeft, contentDescription = "Назад") }
        }
        items.forEach { item ->
            val tint = if (item.enabled) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.35f)
            Column(
                Modifier
                    .width(76.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .clickable(enabled = item.enabled, onClick = item.onClick)
                    .padding(vertical = 6.dp, horizontal = 4.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                Icon(item.icon, contentDescription = null, tint = tint, modifier = Modifier.size(26.dp))
                Text(
                    item.label,
                    modifier = Modifier.padding(top = 4.dp),
                    color = tint,
                    fontSize = 11.sp,
                    lineHeight = 13.sp,
                    maxLines = 2,
                    textAlign = TextAlign.Center,
                )
            }
        }
    }
}

// ---------------------------------------------------------------------------------------------
// Панели настроек (нижние листы)
// ---------------------------------------------------------------------------------------------

@Composable
private fun PanelFrame(
    header: @Composable () -> Unit,
    onDone: () -> Unit,
    content: @Composable ColumnScope.() -> Unit,
) {
    Column(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(topStart = 16.dp, topEnd = 16.dp))
            .background(RibbonBg)
    ) {
        Row(
            Modifier
                .fillMaxWidth()
                .height(52.dp)
                .padding(start = 16.dp, end = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(20.dp),
        ) {
            Row(Modifier.weight(1f), horizontalArrangement = Arrangement.spacedBy(20.dp), verticalAlignment = Alignment.CenterVertically) {
                header()
            }
            IconButton(onClick = onDone) { Icon(Icons.Outlined.Check, contentDescription = "Готово") }
        }
        content()
        Spacer(Modifier.height(8.dp))
    }
}

@Composable
private fun PanelTitle(text: String) {
    Text(text, fontWeight = androidx.compose.ui.text.font.FontWeight.Bold, fontSize = 16.sp)
}

@Composable
private fun PanelTab(text: String, selected: Boolean, onClick: () -> Unit) {
    Column(
        Modifier.clickable(onClick = onClick),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Text(
            text,
            fontWeight = androidx.compose.ui.text.font.FontWeight.Bold,
            fontSize = 16.sp,
            color = if (selected) MaterialTheme.colorScheme.onSurface else Muted,
        )
        Box(
            Modifier
                .padding(top = 4.dp)
                .width(24.dp)
                .height(2.dp)
                .background(if (selected) Accent else Color.Transparent)
        )
    }
}

@Composable
private fun FilterRow(current: FilterPreset, onPick: (FilterPreset) -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .horizontalScroll(rememberScrollState())
            .padding(horizontal = 12.dp, vertical = 8.dp),
        horizontalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        FilterPreset.entries.forEach { f ->
            val sel = f == current
            Box(
                Modifier
                    .size(width = 84.dp, height = 84.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .background(if (sel) Accent.copy(alpha = 0.18f) else SurfaceHigh)
                    .border(if (sel) 2.dp else 1.dp, if (sel) Accent else Color(0xFF3A3E49), RoundedCornerShape(10.dp))
                    .clickable { onPick(f) }
                    .padding(6.dp),
                contentAlignment = Alignment.Center,
            ) {
                Text(f.label, textAlign = TextAlign.Center, fontSize = 13.sp, maxLines = 2)
            }
        }
    }
}

@Composable
private fun AspectRow(current: AspectPreset, onPick: (AspectPreset) -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .horizontalScroll(rememberScrollState())
            .padding(horizontal = 8.dp, vertical = 4.dp),
        horizontalArrangement = Arrangement.spacedBy(4.dp),
    ) {
        AspectPreset.entries.forEach { p ->
            val sel = p == current
            Column(
                Modifier
                    .clip(RoundedCornerShape(10.dp))
                    .clickable { onPick(p) }
                    .padding(horizontal = 10.dp, vertical = 8.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                Box(Modifier.size(52.dp), contentAlignment = Alignment.Center) {
                    val r = p.ratio ?: 1f
                    val w = if (r >= 1f) 48.dp else (48f * r).dp
                    val h = if (r >= 1f) (48f / r).dp else 48.dp
                    Box(
                        Modifier
                            .size(w, h)
                            .clip(RoundedCornerShape(6.dp))
                            .background(if (sel) Accent.copy(alpha = 0.22f) else SurfaceHigh)
                            .border(if (sel) 2.dp else 1.dp, if (sel) Accent else Color(0xFF3A3E49), RoundedCornerShape(6.dp)),
                        contentAlignment = Alignment.Center,
                    ) {
                        if (p == AspectPreset.ORIGINAL) {
                            Icon(Icons.Outlined.AspectRatio, contentDescription = null, modifier = Modifier.size(20.dp), tint = Muted)
                        }
                    }
                }
                Text(
                    p.label,
                    modifier = Modifier.padding(top = 4.dp),
                    fontSize = 12.sp,
                    color = if (sel) Accent else MaterialTheme.colorScheme.onSurface,
                )
            }
        }
    }
}

@Composable
private fun AdjustPanel(
    adjust: Adjust,
    onLive: (Adjust?) -> Unit,
    onCommit: (Adjust) -> Unit,
) {
    var which by remember { mutableIntStateOf(0) }
    var local by remember(adjust) { mutableStateOf(adjust) }
    val knobs = listOf(
        Triple(Icons.Outlined.WbSunny, "Яркость", 0),
        Triple(Icons.Outlined.Contrast, "Контраст", 1),
        Triple(Icons.Outlined.Palette, "Насыщ.", 2),
    )
    Row(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 12.dp, vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceEvenly,
    ) {
        knobs.forEach { (icon, label, index) ->
            val sel = which == index
            Column(
                Modifier
                    .clip(RoundedCornerShape(10.dp))
                    .clickable { which = index }
                    .padding(8.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                Box(
                    Modifier
                        .size(52.dp)
                        .clip(CircleShape)
                        .background(if (sel) Accent.copy(alpha = 0.18f) else SurfaceHigh)
                        .border(if (sel) 2.dp else 1.dp, if (sel) Accent else Color(0xFF3A3E49), CircleShape),
                    contentAlignment = Alignment.Center,
                ) { Icon(icon, contentDescription = null, tint = if (sel) Accent else MaterialTheme.colorScheme.onSurface) }
                Text(label, modifier = Modifier.padding(top = 4.dp), fontSize = 12.sp)
            }
        }
    }
    Row(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Slider(
            value = local.get(which),
            onValueChange = {
                local = local.with(which, it)
                onLive(local)
            },
            onValueChangeFinished = {
                onCommit(local)
                onLive(null)
            },
            valueRange = -1f..1f,
            modifier = Modifier.weight(1f),
        )
        Text(
            "%+d".format((local.get(which) * 100).roundToInt()),
            modifier = Modifier.width(48.dp),
            textAlign = TextAlign.End,
            style = MaterialTheme.typography.bodyMedium,
        )
    }
    TextButton(
        onClick = {
            local = Adjust()
            onCommit(Adjust())
            onLive(null)
        },
        enabled = !adjust.isNeutral || !local.isNeutral,
        modifier = Modifier.padding(start = 8.dp),
    ) {
        Icon(Icons.Outlined.Refresh, contentDescription = null, modifier = Modifier.size(18.dp))
        Text("Сброс", modifier = Modifier.padding(start = 6.dp))
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun TrimPanel(clip: Clip, onTrim: (Long, Long) -> Unit) {
    var range by remember(clip.id, clip.startMs, clip.endMs) {
        mutableStateOf(clip.startMs.toFloat()..clip.endMs.toFloat())
    }
    Column(Modifier.padding(horizontal = 16.dp)) {
        Text(
            "${formatTime(range.start.toLong())} – ${formatTime(range.endInclusive.toLong())}" +
                "   (длина ${formatTime((range.endInclusive - range.start).toLong())})",
            style = MaterialTheme.typography.bodyMedium,
        )
        RangeSlider(
            value = range,
            onValueChange = { range = it },
            valueRange = 0f..clip.sourceDurationMs.toFloat(),
            onValueChangeFinished = { onTrim(range.start.toLong(), range.endInclusive.toLong()) },
        )
    }
}

// ---------------------------------------------------------------------------------------------
// Таймлайн: линейка, дорожка с кадрами, фиксированный курсор по центру, масштаб щипком
// ---------------------------------------------------------------------------------------------

@Composable
private fun TimelineView(
    clips: List<Clip>,
    selectedId: String?,
    playheadMs: Long,
    totalMs: Long,
    dpPerSec: Float,
    onSelect: (String) -> Unit,
    onUserSeek: (Long) -> Unit,
    onZoom: (Float) -> Unit,
    onAdd: () -> Unit,
    addEnabled: Boolean,
) {
    val scroll = rememberScrollState()
    val density = LocalDensity.current
    val pxPerMs = dpPerSec * density.density / 1000f

    val curPxPerMs by rememberUpdatedState(pxPerMs)
    val curPlayhead by rememberUpdatedState(playheadMs)
    val curTotal by rememberUpdatedState(totalMs)
    val curSeek by rememberUpdatedState(onUserSeek)
    val curZoom by rememberUpdatedState(onZoom)

    // Курсор → прокрутка (при воспроизведении, тапах, масштабировании), пока пользователь не листает сам.
    LaunchedEffect(playheadMs, pxPerMs, scroll.maxValue) {
        if (!scroll.isScrollInProgress) {
            val target = (playheadMs * pxPerMs).roundToInt()
            if (abs(target - scroll.value) > 1) scroll.scrollTo(target)
        }
    }
    // Прокрутка пальцем → перемотка предпросмотра.
    LaunchedEffect(scroll) {
        snapshotFlow { scroll.value }.collect { value ->
            if (!scroll.isScrollInProgress) return@collect
            val ms = (value / curPxPerMs).toLong().coerceIn(0, curTotal)
            if (abs(ms - curPlayhead) * curPxPerMs > 3f) curSeek(ms)
        }
    }

    BoxWithConstraints(
        Modifier
            .fillMaxWidth()
            .height(116.dp)
            .background(MaterialTheme.colorScheme.background)
            .pointerInput(Unit) {
                // Масштабирование двумя пальцами; одиночные касания и прокрутка не затрагиваются.
                awaitEachGesture {
                    awaitFirstDown(requireUnconsumed = false, pass = PointerEventPass.Initial)
                    do {
                        val event = awaitPointerEvent(PointerEventPass.Initial)
                        if (event.changes.size >= 2) {
                            val zoom = event.calculateZoom()
                            if (zoom != 1f) {
                                curZoom(zoom)
                                event.changes.forEach { it.consume() }
                            }
                        }
                    } while (event.changes.any { it.pressed })
                }
            }
    ) {
        val halfWidth = maxWidth / 2

        if (clips.isEmpty()) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("Здесь появится таймлайн", color = Muted, fontSize = 13.sp)
            }
        } else {
            Box(
                Modifier
                    .fillMaxSize()
                    .horizontalScroll(scroll)
            ) {
                Row(Modifier.fillMaxHeight()) {
                    Spacer(Modifier.width(halfWidth))
                    Column {
                        Ruler(totalMs = totalMs, dpPerSec = dpPerSec)
                        Spacer(Modifier.height(8.dp))
                        Row {
                            clips.forEach { c ->
                                ClipTile(
                                    clip = c,
                                    selected = c.id == selectedId,
                                    dpPerSec = dpPerSec,
                                    onClick = { onSelect(c.id) },
                                )
                            }
                        }
                    }
                    Spacer(Modifier.width(halfWidth))
                }
            }
            // Фиксированный курсор по центру
            Box(
                Modifier
                    .align(Alignment.TopCenter)
                    .width(2.dp)
                    .fillMaxHeight()
                    .background(Color.White)
            )
            // Кнопка «добавить клип» у правого края дорожки
            Box(
                Modifier
                    .align(Alignment.TopEnd)
                    .padding(top = 36.dp, end = 8.dp)
                    .size(48.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(Color.White)
                    .clickable(enabled = addEnabled, onClick = onAdd),
                contentAlignment = Alignment.Center,
            ) { Icon(Icons.Outlined.Add, contentDescription = "Добавить клип", tint = Color.Black) }
        }
    }
}

@Composable
private fun Ruler(totalMs: Long, dpPerSec: Float) {
    val steps = listOf(1, 2, 5, 10, 30, 60, 120, 300, 600)
    val stepSec = steps.firstOrNull { it * dpPerSec >= 64f } ?: steps.last()
    val totalSec = ceil(totalMs / 1000f).toInt()
    val totalWidth = (totalMs / 1000f * dpPerSec).dp
    Box(
        Modifier
            .width(totalWidth)
            .height(24.dp)
            .clipToBounds()
    ) {
        Row(Modifier.wrapContentWidth(Alignment.Start, unbounded = true)) {
            for (t in 0..totalSec step stepSec) {
                Box(Modifier.width((stepSec * dpPerSec).dp)) {
                    Text(
                        formatClock(t * 1000L),
                        color = Muted,
                        fontSize = 10.sp,
                        modifier = Modifier.align(Alignment.CenterStart),
                    )
                }
            }
        }
    }
}

@Composable
private fun ClipTile(clip: Clip, selected: Boolean, dpPerSec: Float, onClick: () -> Unit) {
    val width = (clip.durationMs / 1000f * dpPerSec).dp.coerceAtLeast(4.dp)
    val tileWidth = 56.dp
    val count = ceil(width / tileWidth).toInt().coerceIn(1, 40)
    val thumbs = rememberClipThumbnails(clip, count)
    val shape = RoundedCornerShape(6.dp)

    Box(
        Modifier
            .width(width)
            .height(60.dp)
            .clip(shape)
            .background(SurfaceHigh)
            .clickable(onClick = onClick)
    ) {
        Row(Modifier.fillMaxSize()) {
            thumbs.forEach { bmp ->
                Box(Modifier.weight(1f).fillMaxHeight()) {
                    if (bmp != null) {
                        Image(
                            bitmap = bmp,
                            contentDescription = null,
                            contentScale = ContentScale.Crop,
                            modifier = Modifier.fillMaxSize(),
                        )
                    }
                }
            }
        }
        if (selected) {
            Box(
                Modifier
                    .fillMaxSize()
                    .border(2.dp, Color.White, shape)
            )
            Text(
                "%.1fs".format(clip.durationMs / 1000f),
                modifier = Modifier
                    .padding(4.dp)
                    .clip(RoundedCornerShape(4.dp))
                    .background(Color(0xAA000000))
                    .padding(horizontal = 4.dp, vertical = 1.dp),
                fontSize = 10.sp,
                color = Color.White,
            )
        }
    }
}

private fun formatClock(ms: Long): String {
    val totalSec = (ms.coerceAtLeast(0) / 1000)
    return "%02d:%02d".format(totalSec / 60, totalSec % 60)
}

private fun formatTime(ms: Long): String {
    val total = ms.coerceAtLeast(0)
    val minutes = total / 60_000
    val seconds = (total / 1000) % 60
    val tenths = (total / 100) % 10
    return "%d:%02d.%d".format(minutes, seconds, tenths)
}
